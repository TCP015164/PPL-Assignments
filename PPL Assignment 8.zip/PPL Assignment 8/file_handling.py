# Exception Handling

# Execute examples one by one



# Ex 1:
# Checking for invalid input
# Here if user mistakenly entered invalid input still the program is not terminated
i=0
print("Enter five numbers\n")
while(i<5):
	try:
		n=int(input("enter a number: "))
		i+=1
	except:
		print("Enter a number only")


'''
# Ex 2:
try:
	x=9
	import Math as m
	print(m.sqrt(x))
except NameError:
	print("x is not defined")
except Exception as UnidentifiedModuleError:
	print("No module named Math was found")
finally:
	print("Use pre-defined module")



# Ex 3:
try:
	a=2
	b=0
	c=ab
except TypeError:
	print("Invalid Syntax")
except Exception as NameError:
	print("name ab is not defined")
finally:
	print("Operator is expected between numbers")



# Ex 4:
a=6
b="input"
try:
	print(a+b)
except NameError:
	print("name a+b is not defined")
except Exception as e:
	print("NewError: "+str(e))
finally:
	print("String literal can't be add with a number")



# Ex 5:
for i in range(6):
	if (i == 4):
		raise ZeroDivisionError("Oops!Error has occurred.\n \t   Impossible to divide by Zero")
	c=6*i//(4-i)
	print(c)



# Ex 6:
# Python program to handle simple runtime error 
  
a = [1, 2, 3, 0] 
try:  
    print(f"Second element = {a[1]}") 
  
    # Throws error since there are only 4 elements in array 
    print(f"Second element = {a[4]}") 
  
except IndexError: 
    print ("Index is out of range for a given list")



# Ex 7:
# Program to handle multiple errors with one except statement 
try : 
	a = 5
	if a < 4 : 

		# ZeroDivisionError for a = 3 
		b = a/(a-3) 
	
	# NameError if a >= 4 
	print("Value of b = ", b) 

# except with multiple exceptions 
except(ZeroDivisionError, NameError): 
	print("Error has Occurred and it has been Handled")


'''