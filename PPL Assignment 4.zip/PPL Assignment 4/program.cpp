#include<iostream>
using namespace std;


// function swap which takes arguments as reference of original arguments and swaps it
void Swap(int &num1, int &num2) {
  int temp = num1;
  num1 = num2;
  num2 = temp;
}

int main() {
  int num1 = 10;
  int num2 = 20;

  cout << "Before swap: " << "\n";
  cout << " num1 = " << num1 << " And  num2 = " << num2 << "\n";

  // Calling swap function, which will change the values of num1 and num2
  Swap(num1, num2);

  cout << "After swap: " << "\n";
  cout << " num1 = " << num1 << " And  num2 = " << num2 << "\n";

  return 0;
}