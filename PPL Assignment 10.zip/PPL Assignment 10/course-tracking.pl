% ------ prolog program for course tracking -------

teaches_course(jatinSir, math).
teaches_course(jatinSir, linearAlgebra).

teaches_course(dattaSir, calculus).
teaches_course(dattaSir, geometry).

teaches_course(sumitSir, ppl).
teaches_course(sumitSir, deepLearning).

teaches_course(vaibhavSir, ppl).
teaches_course(vaibhavSir, machineLearning).

teaches_course(sandeepSir, fcs).
teaches_course(sandeepSir, controlSystem).

teaches_course(deepakSir, dtl).
teaches_course(deepakSir, shellProgramming).

teaches_course(ashwiniMaam, dsa).
teaches_course(ashwiniMaam, dataScience).

teaches_course(rohiniMaam, dsgt).
teaches_course(rohiniMaam, internetSecurity).



include_course(maths, math).
include_course(maths, linearAlgebra).
include_course(maths, calculus).
include_course(maths, geometry).

include_course(mechanics, fcs).
include_course(meachanics, controlSystem).

include_course(cs, dsa).
include_course(cs, dataScience).
include_course(cs, ppl).
include_course(cs, deepLearning).
include_course(cs, machineLearning).

include_course(it, shellProgramming).
include_course(it, dsgt).
include_course(it, internetSecurity).
include_course(it, dtl).


enrolled_course(student1, ppl).
enrolled_course(student1, math).
enrolled_course(student1, dsa).
enrolled_course(student1, machineLearning).
enrolled_course(student1, geometry).

enrolled_course(student2, dsgt).
enrolled_course(student2, linearAlgebra).
enrolled_course(student2, dataScience).
enrolled_course(student2, fcs).
enrolled_course(student2, dtl).

enrolled_course(student3, internetSecurity).
enrolled_course(student3, deepLearning).
enrolled_course(student3, calculus).
enrolled_course(student3, shellProgramming).
enrolled_course(student3, controlSystem).



belongs_to(Faculty, Dept) :- teaches_course(Faculty, Course), include_course(Dept, Course).

has_student(Dept, Student) :- enrolled_course(Student, Course), include_course(Dept, Course).

has_faculty(Student, Faculty) :-  belongs_to(Faculty, Dept), has_student(Dept, Student).