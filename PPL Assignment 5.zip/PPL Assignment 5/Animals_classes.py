
# Parent class : Animals
class Animals:
    "This is parent class : Animal"

    def __init__(self):
        self.eyes = 2


# sub class of Animals : birds
class birds(Animals):
    def __init__(self, wings=2, place="In the Nests"):
        self.place = place
        self.wings = wings

# sub class of birds : sparrow
sparrow = birds(2)
sparrow.sound = "Chew Chew!\n"

# sub class of birds : crow
crow = birds(2, "On Trees")
crow.sound = "Cow Cow!\n"


# sub class of Animals : carnivores
class carnivores(Animals):
    def __init__(self, legs=4, sound=""):
        self.legs = legs
        self.sound = sound  
        self.habitat = "Forest"
        self.food = "meat"

# sub class of carnivores : lion
lion = carnivores(4, "roar")
lion.color = "Brown"
        

# sub class of carnivores : wolf
wolf = carnivores(4, "howl")
wolf.color = "Grey"


# sub class of carnivores : polar_Bear
polar_Bear = carnivores(4, "hissing, squalling, whimpering")
polar_Bear.color = "White"
polar_Bear.habitat = "Glacier"


# sub class of Animals : herbivores
class herbivores(Animals):
    def __init__(self, legs=4, sound = ""):
        self.legs = legs
        self.sound = sound  
        self.habitat = "Forest"
        self.food = "Plants and Fruits"


# sub class of herbivores : goat
goat = herbivores(4, "meh meh!")
goat.color = "Black"
        
# sub class of herbivores : elephant
elephant = herbivores(4, "trumpet")
elephant.color = "Grey"


# sub class of herbivores : panda
panda = herbivores(4, "bleat!")
panda.color = "Black and White"

        
# sub class of Animals : domestic_animals 
class domestic_animals(Animals):
    def __init__(self, legs=4, sound ="", food=""):
        self.legs = legs
        self.sound = sound
        self.food = food
        self.habitat = "Areas habitated by human beings"

# sub class of domestic_animals : dog        
dog = domestic_animals(4, "Bark", "milk")
dog.color ="brown, black, white, golden, etc"
        
# sub class of domestic_animals : cat        
cat = domestic_animals(4, "meow", "milk")
cat.color ="brown, black, white, golden, etc"
        

# sub class of domestic_animals : cow        
cow = domestic_animals(4, "moo", "grass")
cow.color ="brown, black, white, golden, etc"


print(Animals.__doc__)

print("----------- Birds ------------\n\n --- Sparrow  ---- \n habitat = {0}   wings = {1}    sound = {2}\n" .format(sparrow.place, sparrow.wings, sparrow.sound))
print("--- Crow --- \n habitat = {0}   wings = {1}    sound = {2}\n" .format(crow.place, crow.wings, crow.sound))


print("\n\n ------------ Carnivores -----------\n")
print(" --- Lion --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
lion.habitat, lion.legs, lion.sound, lion.food, lion.color))
print(" --- Wolf --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
wolf.habitat, wolf.legs, wolf.sound, wolf.food, wolf.color))
print(" --- Polar bear --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
polar_Bear.habitat, polar_Bear.legs, polar_Bear.sound, polar_Bear.food, polar_Bear.color))

print("\n\n------------ Herbivores -----------\n")
print(" --- Goat --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
goat.habitat, goat.legs, goat.sound, goat.food, goat.color))
print(" --- Panda --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
panda.habitat, panda.legs, panda.sound, panda.food, panda.color))
print(" --- Elephant --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
elephant.habitat, elephant.legs, elephant.sound, elephant.food, elephant.color))


print("\n\n ------------- Domestic Animals   ---------------\n")
print(" --- dog --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}   color = {4}\n".format(
dog.habitat, dog.legs, dog.sound, dog.food, dog.color))
print(" --- Cat --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
cat.habitat, cat.legs, cat.sound, cat.food, cat.color))
print(" --- cow --- \n habitat = {0}    legs = {1}    sound = {2}    food = {3}    color = {4}\n".format(
cow.habitat, cow.legs, cow.sound, cow.food, cow.color))