import turtle as t
scr = t.Screen()
scr.title("Shapes Representation")
scr.bgcolor("black")

obj = t.Turtle()

obj.width(1)
obj.color("red")
obj.fillcolor("green")
obj.shape("turtle")
obj.begin_fill()


# Polygon Class
class Polygon():
    def __init__(self, side = 4, length = 100):
        self.side = side
        self.length = length 
    
    def show(self):
        for i in range(self.side):
            obj.forward(self.length)
            obj.left(360/self.side)
            obj.stamp()

# circle
def circle(rad):
    obj.circle(rad)


# 3 : Rectangle
def rectangle(length, breadth):
    for i in range(4):
        if(i%2 == 0):
            obj.forward(length)
        else:
            obj.forward(breadth)
        obj.left(90)


# 8: Star
def star(length):
    for i in range(5):
        obj.forward(length)
        obj.right(144)


# 9 : Double Cone
def doub_cone(length):
    for i in range(5):
        if(i < 3):
            obj.left(120)
        else:
            obj.right(120)
        obj.forward(length)


# 10 : Spiral Helix Pattern
def spiral_hex():
    s = t.Pen()
    s.pencolor("yellow")
    s.width(1)
    for i in range(1,25):
        s.circle(10+i)
        s.circle(-(10+i))
        s.left(i)


def spider_web():
    colors = ["red", "yellow"]
    s = t.Pen()
    for i in range(120):
        s.pencolor(colors[i%2])
        s.width(i/100+1)
        s.forward(i)
        s.left(60)

''' Instruction : Run each shape function one by one to view output '''

# spider_web()

# circle(100)

# rectangle(200,100)

# star(300)

# doub_cone(100)

# spiral_hex()

# triangle = Polygon(3,200) 
# triangle.show() 

# square = Polygon(4,200) 
# square.show() 

# pentagon = Polygon(5,100) 
# pentagon.show() 

# hexagon = Polygon(6,100) 
# hexagon.show() 

# octagon = Polygon(8,100) 
# octagon.show() 

obj.end_fill()

t.done()